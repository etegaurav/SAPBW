-- test the current user
SELECT CURRENT_USER FROM DUMMY; 

-- Create virtual tables via ABAPTABLES, SAPI, standard schema;

CREATE VIRTUAL TABLE "U##_VT_T41_KNA1" AT "ABAPT41_##"."NULL"."ABAPTABLES"."KNA1";
CREATE VIRTUAL TABLE "U##_VT_T41_2LIS11VAITM" AT "ABAPT41_##"."NULL"."SAPI"."2LIS_11_VAITM";
CREATE VIRTUAL TABLE "VT_IQ_dbo" AT "IQ16_WDFLBMT7211"."NULL"."dbo"."RowGenerator";
-- test the join

SELECT VBELN, POSNR, I.ERDAT, I.KUNNR, NAME1, ORT01, VKORG, MATNR, KWMENG, VRKME, NETWR, WAERK 
FROM "STUDENT##"."U##_VT_T41_2LIS11VAITM" as I 
INNER JOIN "STUDENT##"."U##_VT_T41_KNA1" AS K ON I.KUNNR = K.KUNNR


-- To use a remote source for Open ODS Views, you need to execute the following statement if HANA user SAPCIA is used by BW/4HANA:
GRANT LINKED DATABASE, CREATE VIRTUAL TABLE ON REMOTE SOURCE ABAPT41_## to SAPCIA;

-- To create virtual tables as STUDENT##, you would need: 
GRANT CREATE VIRTUAL TABLE ON REMOTE SOURCE "ABAPT41_##" to STUDENT##;

-- (or for all students:)

GRANT CREATE VIRTUAL TABLE ON REMOTE SOURCE "ABAPT41_##" to TRAINING_USER_ROLE;

-- Grant access on your schema to the SAP BW/4HANA background user (SAPCIA) using the following SQL statement.
GRANT SELECT ON SCHEMA "STUDENT##" to SAPCIA; 

