-- to find out your user / schema, you can use the following statements:
SELECT CURRENT_USER fROM DUMMY; 
SELECT CURRENT_SCHEMA fROM DUMMY; 

-- Replace STUDENT## with your user name in the following statement and execute it:
GRANT SELECT, SELECT METADATA ON SCHEMA STUDENT## TO SAPCIA;