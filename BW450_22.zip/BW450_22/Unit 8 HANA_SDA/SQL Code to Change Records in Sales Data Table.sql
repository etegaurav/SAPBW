-- This file contains SQL statements to change source data
-- Please first substitute ## with your number, 
-- then execute these statements from SAP HANA database (SQL console) with your STUDENT## user.

-- Change records
UPDATE "TRAINING"."SALES_DATA_##" SET QUANTITY = 99 WHERE QUANTITY = 1; 

-- Delete records
DELETE FROM "TRAINING"."SALES_DATA_##" WHERE QUANTITY = 5;